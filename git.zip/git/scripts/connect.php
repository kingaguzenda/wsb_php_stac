<?php
	$conn = new mysqli("localhost", "root", "", "wsb_diinz_2_k14_inf");
	//echo "db";
	//echo $conn->connect_errno;