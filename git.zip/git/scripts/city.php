<?php
	echo <<< LIST
		<ul>
			<li>Poznań</li>
			<li>Gniezno</li>
			<li>Września</li>
		</ul>
LIST;

